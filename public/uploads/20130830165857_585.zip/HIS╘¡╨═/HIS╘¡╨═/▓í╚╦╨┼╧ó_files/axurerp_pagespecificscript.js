﻿for(var i = 0; i < 59; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
document.getElementById('u31_img').tabIndex = 0;

u31.style.cursor = 'pointer';
$axure.eventManager.click('u31', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('入院许可.html');

}
});
u36.tabIndex = 0;

u36.style.cursor = 'pointer';
$axure.eventManager.click('u36', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('诊断结果.html');

}
});
gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u17'] = 'center';document.getElementById('u28_img').tabIndex = 0;

u28.style.cursor = 'pointer';
$axure.eventManager.click('u28', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('开处方.html');

}
});
gv_vAlignTable['u29'] = 'center';u30.tabIndex = 0;

u30.style.cursor = 'pointer';
$axure.eventManager.click('u30', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('开处方.html');

}
});
gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u58'] = 'center';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u38'] = 'center';document.getElementById('u43_img').tabIndex = 0;

u43.style.cursor = 'pointer';
$axure.eventManager.click('u43', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('门诊.html');

}
});
gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u1'] = 'center';document.getElementById('u37_img').tabIndex = 0;

u37.style.cursor = 'pointer';
$axure.eventManager.click('u37', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('医嘱.html');

}
});
gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u3'] = 'center';u39.tabIndex = 0;

u39.style.cursor = 'pointer';
$axure.eventManager.click('u39', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('医嘱.html');

}
});
gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u56'] = 'center';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u5'] = 'center';document.getElementById('u2_img').tabIndex = 0;

u2.style.cursor = 'pointer';
$axure.eventManager.click('u2', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('index.html');

}
});
gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u48'] = 'center';document.getElementById('u49_img').tabIndex = 0;

u49.style.cursor = 'pointer';
$axure.eventManager.click('u49', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('药房药库.html');

}
});
gv_vAlignTable['u50'] = 'center';document.getElementById('u45_img').tabIndex = 0;

u45.style.cursor = 'pointer';
$axure.eventManager.click('u45', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('住院登记收费.html');

}
});
gv_vAlignTable['u52'] = 'center';u33.tabIndex = 0;

u33.style.cursor = 'pointer';
$axure.eventManager.click('u33', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('入院许可.html');

}
});
gv_vAlignTable['u33'] = 'top';document.getElementById('u47_img').tabIndex = 0;

u47.style.cursor = 'pointer';
$axure.eventManager.click('u47', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('住院医生护士站.html');

}
});
document.getElementById('u34_img').tabIndex = 0;

u34.style.cursor = 'pointer';
$axure.eventManager.click('u34', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('诊断结果.html');

}
});
