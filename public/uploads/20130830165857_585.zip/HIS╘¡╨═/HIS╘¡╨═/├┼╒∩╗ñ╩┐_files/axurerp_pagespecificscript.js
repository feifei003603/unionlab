﻿for(var i = 0; i < 129; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u28'] = 'center';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u76'] = 'center';gv_vAlignTable['u90'] = 'center';gv_vAlignTable['u120'] = 'center';gv_vAlignTable['u38'] = 'center';gv_vAlignTable['u102'] = 'center';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u62'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u48'] = 'center';document.getElementById('u4_img').tabIndex = 0;

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('门诊.html');

}
});
gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u68'] = 'center';gv_vAlignTable['u104'] = 'center';gv_vAlignTable['u64'] = 'center';gv_vAlignTable['u30'] = 'center';document.getElementById('u8_img').tabIndex = 0;

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('住院医生护士站.html');

}
});
gv_vAlignTable['u60'] = 'center';gv_vAlignTable['u122'] = 'center';gv_vAlignTable['u34'] = 'center';gv_vAlignTable['u100'] = 'center';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u58'] = 'center';gv_vAlignTable['u74'] = 'center';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u36'] = 'center';gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u126'] = 'center';gv_vAlignTable['u118'] = 'center';gv_vAlignTable['u92'] = 'center';gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u98'] = 'center';document.getElementById('u0_img').tabIndex = 0;

u0.style.cursor = 'pointer';
$axure.eventManager.click('u0', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('index.html');

}
});
gv_vAlignTable['u86'] = 'center';gv_vAlignTable['u84'] = 'center';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u128'] = 'center';gv_vAlignTable['u106'] = 'center';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u124'] = 'center';gv_vAlignTable['u114'] = 'center';gv_vAlignTable['u94'] = 'center';gv_vAlignTable['u96'] = 'center';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u110'] = 'center';gv_vAlignTable['u116'] = 'center';gv_vAlignTable['u56'] = 'center';gv_vAlignTable['u82'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u112'] = 'center';gv_vAlignTable['u72'] = 'center';gv_vAlignTable['u78'] = 'center';gv_vAlignTable['u88'] = 'center';gv_vAlignTable['u80'] = 'center';document.getElementById('u10_img').tabIndex = 0;

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('药房药库.html');

}
});
document.getElementById('u6_img').tabIndex = 0;

u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('住院登记收费.html');

}
});
gv_vAlignTable['u70'] = 'center';gv_vAlignTable['u40'] = 'center';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u108'] = 'center';