﻿for(var i = 0; i < 39; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u28'] = 'center';u29.tabIndex = 0;

u29.style.cursor = 'pointer';
$axure.eventManager.click('u29', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('挂号.html');

}
});
gv_vAlignTable['u29'] = 'top';u32.tabIndex = 0;

u32.style.cursor = 'pointer';
$axure.eventManager.click('u32', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('门诊医生.html');

}
});
gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u13'] = 'center';u38.tabIndex = 0;

u38.style.cursor = 'pointer';
$axure.eventManager.click('u38', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('门诊护士.html');

}
});
gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u37'] = 'center';u26.tabIndex = 0;

u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', function(e) {

if (true) {

	self.location.href='#';

}
});
gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u9'] = 'center';u35.tabIndex = 0;

u35.style.cursor = 'pointer';
$axure.eventManager.click('u35', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('门诊收费.html');

}
});
gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u7'] = 'center';u23.tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('病人.html');

}
});
gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u34'] = 'center';document.getElementById('u0_img').tabIndex = 0;

u0.style.cursor = 'pointer';
$axure.eventManager.click('u0', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('index.html');

}
});
