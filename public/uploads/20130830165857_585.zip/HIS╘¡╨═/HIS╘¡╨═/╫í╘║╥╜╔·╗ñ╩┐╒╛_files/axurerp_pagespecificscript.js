﻿for(var i = 0; i < 42; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u28'] = 'center';u29.tabIndex = 0;

u29.style.cursor = 'pointer';
$axure.eventManager.click('u29', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('挂号.html');

}
});
gv_vAlignTable['u29'] = 'top';document.getElementById('u8_img').tabIndex = 0;

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
document.getElementById('u6_img').tabIndex = 0;

u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('住院登记收费.html');

}
});
u32.tabIndex = 0;

u32.style.cursor = 'pointer';
$axure.eventManager.click('u32', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('门诊医生.html');

}
});
gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u13'] = 'center';document.getElementById('u4_img').tabIndex = 0;

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('门诊.html');

}
});
u38.tabIndex = 0;

u38.style.cursor = 'pointer';
$axure.eventManager.click('u38', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('门诊医生.html');

}
});
gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u40'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u37'] = 'center';u26.tabIndex = 0;

u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', u26Click);
InsertAfterBegin(document.body, "<div class='intcases' id='u26LinksClick'></div>")
var u26LinksClick = document.getElementById('u26LinksClick');
function u26Click(e) 
{
windowEvent = e;


	ToggleLinks(e, 'u26LinksClick');
}

InsertBeforeEnd(u26LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u26Clickuac246bf55d4f48bfae3f1b5554690240(event)'>用例 1</div>");
function u26Clickuac246bf55d4f48bfae3f1b5554690240(e)
{

	self.location.href='#';

	ToggleLinks(e, 'u26LinksClick');
}

InsertBeforeEnd(u26LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u26Clicku8c5e125d5b8f44929aec5cb2eb50b07c(event)'>用例 2</div>");
function u26Clicku8c5e125d5b8f44929aec5cb2eb50b07c(e)
{

	self.location.href=$axure.globalVariableProvider.getLinkUrl('取消登记.html');

	ToggleLinks(e, 'u26LinksClick');
}
gv_vAlignTable['u26'] = 'top';u41.tabIndex = 0;

u41.style.cursor = 'pointer';
$axure.eventManager.click('u41', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('门诊医生.html');

}
});
gv_vAlignTable['u41'] = 'top';document.getElementById('u10_img').tabIndex = 0;

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('药房药库.html');

}
});
gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u9'] = 'center';u35.tabIndex = 0;

u35.style.cursor = 'pointer';
$axure.eventManager.click('u35', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('门诊医生.html');

}
});
gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u7'] = 'center';u23.tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', u23Click);
InsertAfterBegin(document.body, "<div class='intcases' id='u23LinksClick'></div>")
var u23LinksClick = document.getElementById('u23LinksClick');
function u23Click(e) 
{
windowEvent = e;


	ToggleLinks(e, 'u23LinksClick');
}

InsertBeforeEnd(u23LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u23Clicku28488927960643e59d2866a9782f5122(event)'>用例 1</div>");
function u23Clicku28488927960643e59d2866a9782f5122(e)
{

	self.location.href=$axure.globalVariableProvider.getLinkUrl('病人.html');

	ToggleLinks(e, 'u23LinksClick');
}

InsertBeforeEnd(u23LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u23Clickua291ccd1977c48a699e7414d7bdebfd7(event)'>用例 2</div>");
function u23Clickua291ccd1977c48a699e7414d7bdebfd7(e)
{

	self.location.href=$axure.globalVariableProvider.getLinkUrl('登记.html');

	ToggleLinks(e, 'u23LinksClick');
}
gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u34'] = 'center';document.getElementById('u0_img').tabIndex = 0;

u0.style.cursor = 'pointer';
$axure.eventManager.click('u0', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('index.html');

}
});
