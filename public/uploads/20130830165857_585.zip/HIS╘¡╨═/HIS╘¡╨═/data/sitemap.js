﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h),_(c,i,e,f,g,j,k,[_(c,l,e,f,g,m,k,[_(c,n,e,f,g,o)]),_(c,p,e,f,g,q,k,[_(c,r,e,f,g,s)]),_(c,t,e,f,g,u,k,[_(c,v,e,f,g,w,k,[_(c,x,e,f,g,y),_(c,z,e,f,g,A),_(c,B,e,f,g,C),_(c,D,e,f,g,E)])]),_(c,F,e,f,g,G),_(c,H,e,f,g,I)]),_(c,J,e,f,g,K,k,[_(c,L,e,f,g,M),_(c,N,e,f,g,O,k,[_(c,P,e,f,g,Q)]),_(c,R,e,f,g,S,k,[_(c,T,e,f,g,U)]),_(c,V,e,f,g,W)]),_(c,X,e,f,g,Y),_(c,Z,e,f,g,ba,k,[_(c,bb,e,f,g,bc,k,[_(c,bd,e,f,g,be,k,[_(c,bf,e,f,g,bg)])])])]);}; 
var b="rootNodes",c="pageName",d="index",e="type",f="Wireframe",g="url",h="index.html",i="门诊",j="门诊.html",k="children",l="病人",m="病人.html",n="新增病人",o="新增病人.html",p="挂号",q="挂号.html",r="新增挂号",s="新增挂号.html",t="门诊医生",u="门诊医生.html",v="病人信息",w="病人信息.html",x="开处方",y="开处方.html",z="入院许可",A="入院许可.html",B="诊断结果",C="诊断结果.html",D="医嘱",E="医嘱.html",F="门诊收费",G="门诊收费.html",H="门诊护士",I="门诊护士.html",J="住院登记收费",K="住院登记收费.html",L="登记",M="登记.html",N="取消登记",O="取消登记.html",P="确认登记",Q="确认登记.html",R="出院",S="出院.html",T="费用详单",U="费用详单.html",V="取消出院",W="取消出院.html",X="住院医生护士站",Y="住院医生护士站.html",Z="药房药库",ba="药房药库.html",bb="药品申请",bc="药品申请.html",bd="申请入库",be="申请入库.html",bf="新增供应商",bg="新增供应商.html";
return _creator();
})();
