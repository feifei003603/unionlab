﻿for(var i = 0; i < 13; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u12'] = 'center';
u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('门诊.html');

}
});
gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u2'] = 'top';