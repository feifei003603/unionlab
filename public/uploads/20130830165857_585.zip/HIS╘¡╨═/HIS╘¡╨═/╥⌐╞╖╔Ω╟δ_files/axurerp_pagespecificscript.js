﻿for(var i = 0; i < 33; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u28'] = 'center';u29.tabIndex = 0;

u29.style.cursor = 'pointer';
$axure.eventManager.click('u29', u29Click);
InsertAfterBegin(document.body, "<div class='intcases' id='u29LinksClick'></div>")
var u29LinksClick = document.getElementById('u29LinksClick');
function u29Click(e) 
{
windowEvent = e;


	ToggleLinks(e, 'u29LinksClick');
}

InsertBeforeEnd(u29LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u29Clicku9a9b76b5cf384d479c2572b5ca1d3bec(event)'>用例 1</div>");
function u29Clicku9a9b76b5cf384d479c2572b5ca1d3bec(e)
{

	self.location.href=$axure.globalVariableProvider.getLinkUrl('病人.html');

	ToggleLinks(e, 'u29LinksClick');
}

InsertBeforeEnd(u29LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u29Clicku0be849c36a284342ad2a324de9c651f7(event)'>用例 2</div>");
function u29Clicku0be849c36a284342ad2a324de9c651f7(e)
{

	self.location.href=$axure.globalVariableProvider.getLinkUrl('登记.html');

	ToggleLinks(e, 'u29LinksClick');
}
gv_vAlignTable['u29'] = 'top';document.getElementById('u8_img').tabIndex = 0;

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('住院医生护士站.html');

}
});
document.getElementById('u6_img').tabIndex = 0;

u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('住院登记收费.html');

}
});
gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u13'] = 'center';document.getElementById('u4_img').tabIndex = 0;

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('门诊.html');

}
});
gv_vAlignTable['u1'] = 'center';u26.tabIndex = 0;

u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', u26Click);
InsertAfterBegin(document.body, "<div class='intcases' id='u26LinksClick'></div>")
var u26LinksClick = document.getElementById('u26LinksClick');
function u26Click(e) 
{
windowEvent = e;


	ToggleLinks(e, 'u26LinksClick');
}

InsertBeforeEnd(u26LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u26Clicku4f255c9fed4e4560bfdb4bb90dc5cff1(event)'>用例 1</div>");
function u26Clicku4f255c9fed4e4560bfdb4bb90dc5cff1(e)
{

	self.location.href=$axure.globalVariableProvider.getLinkUrl('病人.html');

	ToggleLinks(e, 'u26LinksClick');
}

InsertBeforeEnd(u26LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u26Clicku1e36286eb06145f4a14c71dcbf8d8de1(event)'>用例 2</div>");
function u26Clicku1e36286eb06145f4a14c71dcbf8d8de1(e)
{

	self.location.href=$axure.globalVariableProvider.getLinkUrl('登记.html');

	ToggleLinks(e, 'u26LinksClick');
}
gv_vAlignTable['u26'] = 'top';document.getElementById('u10_img').tabIndex = 0;

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('药房药库.html');

}
});
gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u7'] = 'center';u23.tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', u23Click);
InsertAfterBegin(document.body, "<div class='intcases' id='u23LinksClick'></div>")
var u23LinksClick = document.getElementById('u23LinksClick');
function u23Click(e) 
{
windowEvent = e;


	ToggleLinks(e, 'u23LinksClick');
}

InsertBeforeEnd(u23LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u23Clickua8628c9aec78431d9f579f2b76bc95e1(event)'>用例 1</div>");
function u23Clickua8628c9aec78431d9f579f2b76bc95e1(e)
{

	self.location.href=$axure.globalVariableProvider.getLinkUrl('病人.html');

	ToggleLinks(e, 'u23LinksClick');
}

InsertBeforeEnd(u23LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u23Clicku9081ec4921d149e3b6dd908f7faa9249(event)'>用例 2</div>");
function u23Clicku9081ec4921d149e3b6dd908f7faa9249(e)
{

	self.location.href=$axure.globalVariableProvider.getLinkUrl('登记.html');

	ToggleLinks(e, 'u23LinksClick');
}
gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u22'] = 'center';document.getElementById('u0_img').tabIndex = 0;

u0.style.cursor = 'pointer';
$axure.eventManager.click('u0', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('index.html');

}
});
