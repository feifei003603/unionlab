﻿for(var i = 0; i < 135; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u65'] = 'center';gv_vAlignTable['u130'] = 'center';gv_vAlignTable['u55'] = 'center';document.getElementById('u76_img').tabIndex = 0;

u76.style.cursor = 'pointer';
$axure.eventManager.click('u76', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('病人信息.html');

}
});
gv_vAlignTable['u128'] = 'center';gv_vAlignTable['u93'] = 'center';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u53'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u115'] = 'center';document.getElementById('u8_img').tabIndex = 0;

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('住院医生护士站.html');

}
});
document.getElementById('u60_img').tabIndex = 0;

u60.style.cursor = 'pointer';
$axure.eventManager.click('u60', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('病人信息.html');

}
});
gv_vAlignTable['u89'] = 'center';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u79'] = 'center';gv_vAlignTable['u81'] = 'center';gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u85'] = 'center';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u71'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u75'] = 'center';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u59'] = 'center';document.getElementById('u92_img').tabIndex = 0;

u92.style.cursor = 'pointer';
$axure.eventManager.click('u92', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('病人信息.html');

}
});
gv_vAlignTable['u83'] = 'center';gv_vAlignTable['u107'] = 'center';gv_vAlignTable['u95'] = 'center';gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u87'] = 'center';gv_vAlignTable['u113'] = 'center';document.getElementById('u0_img').tabIndex = 0;

u0.style.cursor = 'pointer';
$axure.eventManager.click('u0', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('index.html');

}
});
gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u109'] = 'center';gv_vAlignTable['u77'] = 'center';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u99'] = 'center';gv_vAlignTable['u105'] = 'center';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u111'] = 'center';gv_vAlignTable['u69'] = 'center';gv_vAlignTable['u73'] = 'center';document.getElementById('u4_img').tabIndex = 0;

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('门诊.html');

}
});
gv_vAlignTable['u103'] = 'center';gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u61'] = 'center';gv_vAlignTable['u132'] = 'center';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u97'] = 'center';gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u134'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u101'] = 'center';gv_vAlignTable['u43'] = 'center';document.getElementById('u10_img').tabIndex = 0;

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('药房药库.html');

}
});
document.getElementById('u6_img').tabIndex = 0;

u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('住院登记收费.html');

}
});
document.getElementById('u44_img').tabIndex = 0;

u44.style.cursor = 'pointer';
$axure.eventManager.click('u44', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('病人信息.html');

}
});
gv_vAlignTable['u117'] = 'center';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u119'] = 'center';document.getElementById('u108_img').tabIndex = 0;

u108.style.cursor = 'pointer';
$axure.eventManager.click('u108', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('病人信息.html');

}
});
gv_vAlignTable['u91'] = 'center';gv_vAlignTable['u121'] = 'center';